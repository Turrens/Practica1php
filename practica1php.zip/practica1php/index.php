<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Programa de Fichaje</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Programa de Fichaje</h1>

    <div class="row mt-4">
        <div class="col-md-6">
            <form id="formulario">
                <input type="hidden" id="id" name="id">
                <div class="mb-3">
                    <label for="empleado" class="form-label">Nombre del empleado:</label>
                    <input type="text" class="form-control" id="empleado" name="empleado" required>
                </div>
                <div class="mb-3">
                    <label for="accion" class="form-label">Acción:</label>
                    <select class="form-control" id="accion" name="accion" required>
                        <option value="entrada">Entrada</option>
                        <option value="salida">Salida</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Guardar</button>
            </form>
        </div>
    </div>

    <div class="row mt-4">
        <h2>Registros</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Empleado</th>
                    <th>Fecha</th>
                    <th>Acción</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="registros">
            </tbody>
        </table>
    </div>
</div>

<script>
    // Obtener registros y mostrarlos en la tabla
    async function cargarRegistros() {
        try {
            const response = await fetch("obtener_registros.php");
            const registros = await response.json();
            const registrosContainer = document.getElementById("registros");
            registrosContainer.innerHTML = "";

            registros.forEach(registro => {
                const row = document.createElement("tr");

                row.innerHTML = `
                    <td>${registro.id}</td>
                    <td>${registro.empleado}</td>
                    <td>${registro.fecha}</td>
                    <td>${registro.accion}</td>
                    <td>
                        <button class="btn btn-warning btn-sm editar" data-id="${registro.id}">Editar</button>
                        <button class="btn btn-danger btn-sm borrar" data-id="${registro.id}">Borrar</button>
                    </td>
                `;

                registrosContainer.appendChild(row);
            });
        } catch (error) {
            alert("Error al cargar los registros");
            console.error(error);
        }
    }

    // Manejo del formulario para crear o editar registros
    document.getElementById("formulario").addEventListener("submit", async function (e) {
        e.preventDefault();

        const id = document.getElementById("id").value;
        const empleado = document.getElementById("empleado").value;
        const accion = document.getElementById("accion").value;

        const url = id ? "editar.php" : "crear.php";

        const formData = new FormData();
        formData.append("id", id);
        formData.append("empleado", empleado);
        formData.append("accion", accion);

        try {
            const response = await fetch(url, {
                method: "POST",
                body: formData
            });
            const resultado = await response.text();

            alert(resultado);
            document.getElementById("formulario").reset();
            document.getElementById("id").value = "";
            cargarRegistros();
        } catch (error) {
            alert("Error al guardar el registro.");
            console.error(error);
        }
    });

    // Manejo del botón Editar
    document.addEventListener("click", async function (e) {
        if (e.target.classList.contains("editar")) {
            const id = e.target.getAttribute("data-id");

            try {
                const formData = new FormData();
                formData.append("id", id);

                const response = await fetch("obtener_registro.php", {
                    method: "POST",
                    body: formData
                });
                const data = await response.json();

                document.getElementById("id").value = data.id;
                document.getElementById("empleado").value = data.empleado;
                document.getElementById("accion").value = data.accion;
            } catch (error) {
                alert("Error al obtener los datos del registro.");
                console.error(error);
            }
        }
    });

    // Manejo del botón Borrar
    document.addEventListener("click", async function (e) {
        if (e.target.classList.contains("borrar")) {
            const id = e.target.getAttribute("data-id");

            if (confirm("¿Estás seguro de que deseas eliminar este registro?")) {
                try {
                    const formData = new FormData();
                    formData.append("id", id);

                    const response = await fetch("borrar.php", {
                        method: "POST",
                        body: formData
                    });
                    const resultado = await response.text();

                    alert(resultado);
                    cargarRegistros();
                } catch (error) {
                    alert("Error al eliminar el registro.");
                    console.error(error);
                }
            }
        }
    });

    // Cargar registros al inicio
    document.addEventListener("DOMContentLoaded", cargarRegistros);
</script>
</body>
</html>
