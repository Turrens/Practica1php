<?php
include("conexion.php");

if (isset($_POST['id']) && isset($_POST['empleado']) && isset($_POST['accion'])) {
    $id = $_POST['id'];
    $empleado = $_POST['empleado'];
    $accion = $_POST['accion'];

    try {
        if (!empty($id)) {
            // Editar registro existente
            $stmt = $conexion->prepare("UPDATE registros SET empleado = :empleado, accion = :accion WHERE id = :id");
            $stmt->bindParam(':id', $id);
        } else {
            // Crear nuevo registro
            $stmt = $conexion->prepare("INSERT INTO registros (empleado, accion) VALUES (:empleado, :accion)");
        }
        $stmt->bindParam(':empleado', $empleado);
        $stmt->bindParam(':accion', $accion);
        $stmt->execute();

        echo !empty($id) ? "Registro actualizado correctamente." : "Registro guardado correctamente.";
    } catch (PDOException $e) {
        echo "Error al guardar el registro: " . $e->getMessage();
    }
} else {
    echo "Faltan datos.";
}
?>
