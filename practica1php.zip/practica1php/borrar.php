<?php
include("conexion.php");

if (isset($_POST['id'])) {
    $id = $_POST['id'];

    try {
        $stmt = $conexion->prepare("DELETE FROM registros WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        echo "Registro eliminado correctamente.";
    } catch (PDOException $e) {
        echo "Error al borrar el registro: " . $e->getMessage();
    }
} else {
    echo "Faltan datos.";
}
?>
