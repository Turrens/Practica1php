<?php
include("conexion.php");

if (isset($_POST['id'])) {
    $id = $_POST['id'];

    try {
        $stmt = $conexion->prepare("SELECT * FROM registros WHERE id = :id LIMIT 1");
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $registro = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode($registro);
    } catch (PDOException $e) {
        echo json_encode(["error" => "Error al obtener el registro: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["error" => "Faltan datos."]);
}
?>
