<?php
include("conexion.php");

try {
    $stmt = $conexion->prepare("SELECT * FROM registros ORDER BY fecha DESC");
    $stmt->execute();
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($resultados);
} catch (PDOException $e) {
    echo "Error al obtener registros: " . $e->getMessage();
}
?>
